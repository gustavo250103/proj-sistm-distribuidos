# BBS System - Parte 1 (Request-Reply)

## Requisitos
- Python 3.8+
- Node 16+
- npm
- Docker (opcional)

## Instalação (local)

1. Instale dependências Node:
```bash
npm install
