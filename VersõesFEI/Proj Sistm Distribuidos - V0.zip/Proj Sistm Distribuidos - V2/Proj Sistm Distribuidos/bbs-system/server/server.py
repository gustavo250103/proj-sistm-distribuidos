import zmq
import json
from storage import persist_login, persist_channel, load_users, load_channels
from utils import current_timestamp


def start_server():
    context = zmq.Context()
    socket = context.socket(zmq.REP)
    socket.bind("tcp://*:5555")

    print("Servidor iniciado e aguardando conexões na porta 5555...")

    while True:
        try:
            message = socket.recv_string()
        except KeyboardInterrupt:
            print("Servidor interrompido")
            break

        print(f"Mensagem recebida: {message}")

        try:
            message_data = json.loads(message)
        except Exception:
            resp = json.dumps({
                "service": "error",
                "data": {
                    "status": "erro",
                    "timestamp": current_timestamp(),
                    "description": "JSON inválido"
                }
            }, ensure_ascii=False)
            socket.send_string(resp)
            continue

        service = message_data.get("service")

        if service == "login":
            response = handle_login(message_data)
        elif service == "users":
            response = list_users()
        elif service == "channel":
            response = create_channel(message_data)
        elif service == "channels":
            response = list_channels()
        else:
            response = json.dumps({
                "service": service or "unknown",
                "data": {
                    "status": "erro",
                    "timestamp": current_timestamp(),
                    "description": "Serviço desconhecido"
                }
            }, ensure_ascii=False)

        socket.send_string(response)


def handle_login(data):
    user = data.get("data", {}).get("user")
    timestamp = data.get("data", {}).get("timestamp")

    if not user:
        return json.dumps({
            "service": "login",
            "data": {"status": "erro", "timestamp": current_timestamp(), "description": "Campo 'user' faltando"}
        }, ensure_ascii=False)

    # Persistir o login (se timestamp for None, usar timestamp atual)
    persist_login(user, timestamp or current_timestamp())

    return json.dumps({
        "service": "login",
        "data": {"status": "sucesso", "timestamp": current_timestamp(), "description": None}
    }, ensure_ascii=False)


def list_users():
    users = load_users()
    return json.dumps({
        "service": "users",
        "data": {"timestamp": current_timestamp(), "users": users}
    }, ensure_ascii=False)


def create_channel(data):
    channel = data.get("data", {}).get("channel")
    timestamp = data.get("data", {}).get("timestamp")

    if not channel:
        return json.dumps({
            "service": "channel",
            "data": {"status": "erro", "timestamp": current_timestamp(), "description": "Campo 'channel' faltando"}
        }, ensure_ascii=False)

    persist_channel(channel, timestamp or current_timestamp())

    return json.dumps({
        "service": "channel",
        "data": {"status": "sucesso", "timestamp": current_timestamp(), "description": None}
    }, ensure_ascii=False)


def list_channels():
    channels = load_channels()
    return json.dumps({
        "service": "channels",
        "data": {"timestamp": current_timestamp(), "channels": channels}
    }, ensure_ascii=False)


if __name__ == "__main__":
    start_server()
