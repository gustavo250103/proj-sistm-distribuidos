import time


def current_timestamp():
    return time.strftime("%Y-%m-%d %H:%M:%S")
