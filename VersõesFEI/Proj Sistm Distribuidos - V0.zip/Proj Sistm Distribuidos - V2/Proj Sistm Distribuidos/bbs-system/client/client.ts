import { sendMessage } from "./zeromqClient.js"

async function main() {
  console.log("Iniciando cliente...")

  // Exemplo: login
  const loginReq = { service: "login", data: { user: "gustavo", timestamp: new Date().toISOString() } }
  console.log("Enviando login...")
  const loginResp = await sendMessage(loginReq)
  console.log("Resposta login:", loginResp)

  // Exemplo: listar usuários
  const usersReq = { service: "users", data: { timestamp: new Date().toISOString() } }
  const usersResp = await sendMessage(usersReq)
  console.log("Resposta users:", usersResp)

  // Exemplo: criar canal
  const createChanReq = { service: "channel", data: { channel: "geral", timestamp: new Date().toISOString() } }
  const createChanResp = await sendMessage(createChanReq)
  console.log("Resposta criar canal:", createChanResp)

  // Exemplo: listar canais
  const channelsReq = { service: "channels", data: { timestamp: new Date().toISOString() } }
  const channelsResp = await sendMessage(channelsReq)
  console.log("Resposta channels:", channelsResp)
}

main().catch((e) => {
  console.error("Erro no cliente:", e)
  process.exit(1)
})
