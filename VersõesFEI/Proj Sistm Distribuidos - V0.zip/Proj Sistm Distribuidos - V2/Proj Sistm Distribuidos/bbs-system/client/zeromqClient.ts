import zmq from "zeromq"

export async function sendMessage(message: object) {
  const sock = new zmq.Request()
  sock.connect("tcp://127.0.0.1:5555")

  // Nota: o socket Request do zeromq fica aberto para enviar/receber
  await sock.send(JSON.stringify(message))
  const [result] = await sock.receive()
  try {
    return JSON.parse(result.toString())
  } catch {
    return { raw: result.toString() }
  } finally {
    try {
      await sock.close()
    } catch {}
  }
}
