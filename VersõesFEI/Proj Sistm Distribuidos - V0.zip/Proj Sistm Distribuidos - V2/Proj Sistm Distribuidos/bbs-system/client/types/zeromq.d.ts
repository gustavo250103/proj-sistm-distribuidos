declare module "zeromq" {
  export class Request {
    constructor()
    connect(endpoint: string): void
    send(msg: string | Uint8Array): Promise<void>
    receive(): Promise<Uint8Array[]>
    close(): Promise<void>
  }
  const _default: {
    Request: typeof Request
  }
  export default _default
}
