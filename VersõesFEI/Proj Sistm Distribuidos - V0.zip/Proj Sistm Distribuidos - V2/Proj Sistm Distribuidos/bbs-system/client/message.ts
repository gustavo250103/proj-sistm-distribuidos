export type ISOTime = string

export interface LoginRequest {
  service: "login"
  data: { user: string; timestamp: ISOTime }
}

export interface LoginResponse {
  service: "login"
  data: { status: "sucesso" | "erro"; timestamp: ISOTime; description?: string | null }
}

export interface UsersRequest {
  service: "users"
  data: { timestamp: ISOTime }
}

export interface UsersResponse {
  service: "users"
  data: { timestamp: ISOTime; users: string[] }
}

export interface ChannelRequest {
  service: "channel"
  data: { channel: string; timestamp: ISOTime }
}

export interface ChannelResponse {
  service: "channel"
  data: { status: "sucesso" | "erro"; timestamp: ISOTime; description?: string | null }
}

export interface ChannelsRequest {
  service: "channels"
  data: { timestamp: ISOTime }
}

export interface ChannelsResponse {
  service: "channels"
  data: { timestamp: ISOTime; channels: string[] }
}
